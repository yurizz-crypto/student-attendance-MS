--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attendance_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance_records (
    id bigint NOT NULL,
    attendance_session_id bigint NOT NULL,
    student_id bigint NOT NULL,
    status character varying(255) DEFAULT 'absent'::character varying NOT NULL,
    remarks character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT attendance_records_status_check CHECK (((status)::text = ANY ((ARRAY['present'::character varying, 'absent'::character varying, 'late'::character varying, 'excused'::character varying])::text[])))
);


ALTER TABLE public.attendance_records OWNER TO postgres;

--
-- Name: attendance_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendance_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendance_records_id_seq OWNER TO postgres;

--
-- Name: attendance_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendance_records_id_seq OWNED BY public.attendance_records.id;


--
-- Name: attendance_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance_sessions (
    id bigint NOT NULL,
    class_section_id bigint NOT NULL,
    date date NOT NULL,
    start_time time(0) without time zone,
    end_time time(0) without time zone,
    status character varying(255) DEFAULT 'open'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    attendance_code character varying(20),
    qr_code_data text,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.attendance_sessions OWNER TO postgres;

--
-- Name: attendance_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendance_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendance_sessions_id_seq OWNER TO postgres;

--
-- Name: attendance_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendance_sessions_id_seq OWNED BY public.attendance_sessions.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    user_id bigint,
    action character varying(255) NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint,
    changes json,
    ip_address character varying(255),
    user_agent character varying(255),
    description text,
    status character varying(255) DEFAULT 'success'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_logs (
    id bigint NOT NULL,
    type character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    file_path character varying(255),
    file_size bigint,
    notes text,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.backup_logs OWNER TO postgres;

--
-- Name: backup_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_logs_id_seq OWNER TO postgres;

--
-- Name: backup_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_logs_id_seq OWNED BY public.backup_logs.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration bigint NOT NULL
);


ALTER TABLE public.cache OWNER TO postgres;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration bigint NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO postgres;

--
-- Name: class_sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_sections (
    id bigint NOT NULL,
    subject_id bigint NOT NULL,
    faculty_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    schedule_details character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    semester_id bigint,
    deleted_at timestamp(0) without time zone,
    lock_version integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.class_sections OWNER TO postgres;

--
-- Name: class_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.class_sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.class_sections_id_seq OWNER TO postgres;

--
-- Name: class_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.class_sections_id_seq OWNED BY public.class_sections.id;


--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.enrollments (
    id bigint NOT NULL,
    class_section_id bigint NOT NULL,
    student_id bigint NOT NULL,
    status character varying(255) DEFAULT 'enrolled'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.enrollments OWNER TO postgres;

--
-- Name: enrollments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.enrollments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.enrollments_id_seq OWNER TO postgres;

--
-- Name: enrollments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.enrollments_id_seq OWNED BY public.enrollments.id;


--
-- Name: excuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.excuses (
    id bigint NOT NULL,
    student_id bigint NOT NULL,
    class_section_id bigint NOT NULL,
    date date,
    reason text NOT NULL,
    file_path character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    attendance_session_id bigint,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.excuses OWNER TO postgres;

--
-- Name: excuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.excuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.excuses_id_seq OWNER TO postgres;

--
-- Name: excuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.excuses_id_seq OWNED BY public.excuses.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO postgres;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    type character varying(255) NOT NULL,
    notifiable_type character varying(255) NOT NULL,
    notifiable_id bigint NOT NULL,
    data text NOT NULL,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: report_configurations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_configurations (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    filters json,
    is_favorite boolean DEFAULT false NOT NULL,
    schedule_frequency character varying(255) DEFAULT 'none'::character varying NOT NULL,
    email_to character varying(255),
    last_run_at timestamp(0) without time zone,
    next_run_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT report_configurations_schedule_frequency_check CHECK (((schedule_frequency)::text = ANY ((ARRAY['none'::character varying, 'daily'::character varying, 'weekly'::character varying, 'monthly'::character varying])::text[]))),
    CONSTRAINT report_configurations_type_check CHECK (((type)::text = ANY ((ARRAY['user_activity'::character varying, 'transaction_summary'::character varying, 'audit_trail'::character varying, 'system_usage'::character varying, 'custom'::character varying])::text[])))
);


ALTER TABLE public.report_configurations OWNER TO postgres;

--
-- Name: report_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_configurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.report_configurations_id_seq OWNER TO postgres;

--
-- Name: report_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_configurations_id_seq OWNED BY public.report_configurations.id;


--
-- Name: semesters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.semesters (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_active boolean DEFAULT true NOT NULL,
    faculty_id bigint
);


ALTER TABLE public.semesters OWNER TO postgres;

--
-- Name: semesters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.semesters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.semesters_id_seq OWNER TO postgres;

--
-- Name: semesters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.semesters_id_seq OWNED BY public.semesters.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subjects (
    id bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.subjects OWNER TO postgres;

--
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subjects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subjects_id_seq OWNER TO postgres;

--
-- Name: subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subjects_id_seq OWNED BY public.subjects.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    first_name character varying(255) NOT NULL,
    middle_name character varying(255),
    last_name character varying(255) NOT NULL,
    identity_id character varying(255) NOT NULL,
    email character varying(255),
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    role character varying(255) DEFAULT 'student'::character varying NOT NULL,
    device_fingerprint character varying(255),
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    avatar_path character varying(255),
    permissions json,
    otp_code character varying(255),
    otp_expires_at timestamp(0) without time zone,
    last_activity timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    lock_version integer DEFAULT 0 NOT NULL,
    notification_preferences json,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'faculty'::character varying, 'student'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: attendance_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_records ALTER COLUMN id SET DEFAULT nextval('public.attendance_records_id_seq'::regclass);


--
-- Name: attendance_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_sessions ALTER COLUMN id SET DEFAULT nextval('public.attendance_sessions_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: backup_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_logs ALTER COLUMN id SET DEFAULT nextval('public.backup_logs_id_seq'::regclass);


--
-- Name: class_sections id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_sections ALTER COLUMN id SET DEFAULT nextval('public.class_sections_id_seq'::regclass);


--
-- Name: enrollments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollments ALTER COLUMN id SET DEFAULT nextval('public.enrollments_id_seq'::regclass);


--
-- Name: excuses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.excuses ALTER COLUMN id SET DEFAULT nextval('public.excuses_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: report_configurations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_configurations ALTER COLUMN id SET DEFAULT nextval('public.report_configurations_id_seq'::regclass);


--
-- Name: semesters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.semesters ALTER COLUMN id SET DEFAULT nextval('public.semesters_id_seq'::regclass);


--
-- Name: subjects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects ALTER COLUMN id SET DEFAULT nextval('public.subjects_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: attendance_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendance_records (id, attendance_session_id, student_id, status, remarks, created_at, updated_at) FROM stdin;
1	1	5	present	Marked present via manual code	2026-05-18 01:27:14	2026-05-18 01:27:14
\.


--
-- Data for Name: attendance_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendance_sessions (id, class_section_id, date, start_time, end_time, status, created_at, updated_at, attendance_code, qr_code_data, deleted_at) FROM stdin;
1	2	2026-05-18	01:26:37	01:31:37	open	2026-05-18 01:26:37	2026-05-18 01:26:37	JWEQBW	1|2|2026-05-18|4	\N
2	1	2026-05-18	01:44:55	01:49:55	closed	2026-05-18 01:44:55	2026-05-18 03:10:42	L4MGS1	2|1|2026-05-18|4	\N
3	1	2026-05-18	03:10:42	03:15:42	open	2026-05-18 03:10:42	2026-05-18 03:10:42	R7ZUJR	3|1|2026-05-18|4	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, action, model_type, model_id, changes, ip_address, user_agent, description, status, created_at, updated_at) FROM stdin;
1	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:24:16	2026-05-17 20:24:16
2	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:32:34	2026-05-17 20:32:34
3	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:34:41	2026-05-17 20:34:41
4	1	imported	App\\Models\\User	\N	{"imported_count":2,"skipped_count":8}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Admin imported 2 users via Excel/CSV (Skipped 8 rows)	success	2026-05-17 20:34:57	2026-05-17 20:34:57
5	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:39:08	2026-05-17 20:39:08
6	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:39:24	2026-05-17 20:39:24
7	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:39:27	2026-05-17 20:39:27
8	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/audit-logs","route":"admin.audit-logs"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/audit-logs	success	2026-05-17 20:39:58	2026-05-17 20:39:58
9	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/reports","route":"admin.reports"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/reports	success	2026-05-17 20:40:01	2026-05-17 20:40:01
10	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/trash","route":"admin.trash"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/trash	success	2026-05-17 20:40:05	2026-05-17 20:40:05
11	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:40:09	2026-05-17 20:40:09
12	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:41:38	2026-05-17 20:41:38
13	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:43:13	2026-05-17 20:43:13
14	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:43:38	2026-05-17 20:43:38
15	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:43:47	2026-05-17 20:43:47
16	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-17 20:43:50	2026-05-17 20:43:50
17	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/excuses","route":"faculty.excuses"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/excuses	success	2026-05-17 20:44:13	2026-05-17 20:44:13
18	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/analytics","route":"faculty.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/analytics	success	2026-05-17 20:44:15	2026-05-17 20:44:15
19	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-17 20:44:17	2026-05-17 20:44:17
20	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:44:19	2026-05-17 20:44:19
21	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:44:28	2026-05-17 20:44:28
22	4	created	App\\Models\\ClassSection	1	{"created":{"subject_id":1,"name":"Section C","schedule_details":"MWF, 10:00 - 12:00"}}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	ClassSection #1 created	success	2026-05-17 20:45:36	2026-05-17 20:45:36
23	4	updated	App\\Models\\ClassSection	1	{"name":{"old":"Section C","new":{"old":"Section C","new":"Section B"}}}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	ClassSection #1 updated	success	2026-05-17 20:45:47	2026-05-17 20:45:47
24	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:47:50	2026-05-17 20:47:50
25	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:48:44	2026-05-17 20:48:44
26	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 20:49:07	2026-05-17 20:49:07
27	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:49:09	2026-05-17 20:49:09
28	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 20:49:10	2026-05-17 20:49:10
29	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:49:18	2026-05-17 20:49:18
30	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:50:09	2026-05-17 20:50:09
31	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:52:10	2026-05-17 20:52:10
32	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 20:52:11	2026-05-17 20:52:11
33	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:52:13	2026-05-17 20:52:13
34	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:52:14	2026-05-17 20:52:14
35	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:52:14	2026-05-17 20:52:14
36	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:52:28	2026-05-17 20:52:28
37	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:52:29	2026-05-17 20:52:29
38	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 20:52:29	2026-05-17 20:52:29
39	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:52:30	2026-05-17 20:52:30
40	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:52:31	2026-05-17 20:52:31
41	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:52:54	2026-05-17 20:52:54
42	4	imported	App\\Models\\ClassSection	\N	{"classes_created":0,"students_enrolled":0}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Faculty imported 0 classes and enrolled 0 students via CSV	success	2026-05-17 20:53:53	2026-05-17 20:53:53
43	4	imported	App\\Models\\ClassSection	\N	{"classes_created":0,"students_enrolled":0}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Faculty imported 0 classes and enrolled 0 students via CSV	success	2026-05-17 20:54:08	2026-05-17 20:54:08
44	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:54:10	2026-05-17 20:54:10
45	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:54:11	2026-05-17 20:54:11
46	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 20:54:12	2026-05-17 20:54:12
47	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:54:13	2026-05-17 20:54:13
48	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:54:14	2026-05-17 20:54:14
49	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:54:30	2026-05-17 20:54:30
50	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:54:32	2026-05-17 20:54:32
51	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 20:54:33	2026-05-17 20:54:33
52	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:54:33	2026-05-17 20:54:33
53	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:54:34	2026-05-17 20:54:34
54	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/audit-logs","route":"admin.audit-logs"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/audit-logs	success	2026-05-17 20:54:45	2026-05-17 20:54:45
55	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/reports","route":"admin.reports"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/reports	success	2026-05-17 20:54:47	2026-05-17 20:54:47
56	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:54:48	2026-05-17 20:54:48
57	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-17 20:54:50	2026-05-17 20:54:50
58	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/excuses","route":"faculty.excuses"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/excuses	success	2026-05-17 20:54:52	2026-05-17 20:54:52
59	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:54:52	2026-05-17 20:54:52
60	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:56:58	2026-05-17 20:56:58
61	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:56:59	2026-05-17 20:56:59
62	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:57:00	2026-05-17 20:57:00
63	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:57:01	2026-05-17 20:57:01
64	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 20:57:01	2026-05-17 20:57:01
65	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:57:37	2026-05-17 20:57:37
66	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:57:39	2026-05-17 20:57:39
67	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 20:57:40	2026-05-17 20:57:40
68	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 20:57:40	2026-05-17 20:57:40
69	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:57:41	2026-05-17 20:57:41
70	4	created	App\\Models\\ClassSection	2	{"created":{"subject_id":2,"name":"Section A","schedule_details":"TTH, 9:00 - 11:00"}}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	ClassSection #2 created	success	2026-05-17 20:58:45	2026-05-17 20:58:45
71	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 20:58:50	2026-05-17 20:58:50
72	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 20:58:55	2026-05-17 20:58:55
73	4	enrolled_student	App\\Models\\ClassSection	2	{"student_id":5}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Student student student enrolled in class	success	2026-05-17 20:59:08	2026-05-17 20:59:08
74	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:05:07	2026-05-17 21:05:07
75	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:05:08	2026-05-17 21:05:08
76	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:05:09	2026-05-17 21:05:09
77	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:05:09	2026-05-17 21:05:09
78	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:05:10	2026-05-17 21:05:10
79	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:05:11	2026-05-17 21:05:11
80	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:05:11	2026-05-17 21:05:11
81	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:05:12	2026-05-17 21:05:12
82	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:05:12	2026-05-17 21:05:12
83	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:05:13	2026-05-17 21:05:13
84	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:05:14	2026-05-17 21:05:14
85	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:06:31	2026-05-17 21:06:31
86	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:06:32	2026-05-17 21:06:32
87	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:06:34	2026-05-17 21:06:34
88	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:06:35	2026-05-17 21:06:35
89	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:06:35	2026-05-17 21:06:35
90	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:08:02	2026-05-17 21:08:02
91	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:08:04	2026-05-17 21:08:04
92	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:08:05	2026-05-17 21:08:05
93	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:08:06	2026-05-17 21:08:06
94	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:08:07	2026-05-17 21:08:07
95	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:08:55	2026-05-17 21:08:55
96	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:08:56	2026-05-17 21:08:56
97	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:08:57	2026-05-17 21:08:57
98	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:08:57	2026-05-17 21:08:57
99	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:09:02	2026-05-17 21:09:02
100	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:09:16	2026-05-17 21:09:16
101	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:09:17	2026-05-17 21:09:17
102	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:09:18	2026-05-17 21:09:18
103	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:09:19	2026-05-17 21:09:19
104	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:09:20	2026-05-17 21:09:20
105	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:09:55	2026-05-17 21:09:55
106	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:09:56	2026-05-17 21:09:56
107	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:09:57	2026-05-17 21:09:57
108	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:09:58	2026-05-17 21:09:58
109	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:09:58	2026-05-17 21:09:58
110	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:16:53	2026-05-17 21:16:53
111	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:16:54	2026-05-17 21:16:54
112	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:16:54	2026-05-17 21:16:54
113	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:16:55	2026-05-17 21:16:55
114	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:16:56	2026-05-17 21:16:56
115	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:17:22	2026-05-17 21:17:22
116	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:17:23	2026-05-17 21:17:23
117	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:17:23	2026-05-17 21:17:23
118	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:17:24	2026-05-17 21:17:24
119	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:17:25	2026-05-17 21:17:25
120	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:21:28	2026-05-17 21:21:28
121	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:21:29	2026-05-17 21:21:29
122	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:21:30	2026-05-17 21:21:30
123	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:21:32	2026-05-17 21:21:32
124	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:21:32	2026-05-17 21:21:32
125	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:22:26	2026-05-17 21:22:26
126	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:22:27	2026-05-17 21:22:27
127	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:22:27	2026-05-17 21:22:27
128	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:22:29	2026-05-17 21:22:29
129	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:22:30	2026-05-17 21:22:30
130	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:22:56	2026-05-17 21:22:56
131	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:22:57	2026-05-17 21:22:57
132	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:22:57	2026-05-17 21:22:57
133	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:23:00	2026-05-17 21:23:00
134	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:23:00	2026-05-17 21:23:00
135	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:28:01	2026-05-17 21:28:01
136	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:28:02	2026-05-17 21:28:02
137	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:28:03	2026-05-17 21:28:03
138	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:28:04	2026-05-17 21:28:04
139	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:28:04	2026-05-17 21:28:04
140	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:28:22	2026-05-17 21:28:22
141	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:28:23	2026-05-17 21:28:23
142	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:28:24	2026-05-17 21:28:24
143	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:28:24	2026-05-17 21:28:24
144	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:28:25	2026-05-17 21:28:25
145	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:29:54	2026-05-17 21:29:54
146	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:29:55	2026-05-17 21:29:55
147	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:29:56	2026-05-17 21:29:56
148	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:29:56	2026-05-17 21:29:56
149	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:29:57	2026-05-17 21:29:57
150	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:29:59	2026-05-17 21:29:59
151	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:30:01	2026-05-17 21:30:01
152	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:30:01	2026-05-17 21:30:01
153	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:30:02	2026-05-17 21:30:02
154	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:30:14	2026-05-17 21:30:14
155	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:30:15	2026-05-17 21:30:15
156	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:30:16	2026-05-17 21:30:16
157	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:30:16	2026-05-17 21:30:16
158	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:30:18	2026-05-17 21:30:18
159	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:30:19	2026-05-17 21:30:19
160	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:30:21	2026-05-17 21:30:21
161	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:30:21	2026-05-17 21:30:21
162	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:30:22	2026-05-17 21:30:22
163	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:30:37	2026-05-17 21:30:37
164	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:30:38	2026-05-17 21:30:38
165	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:30:38	2026-05-17 21:30:38
166	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:30:39	2026-05-17 21:30:39
167	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:30:40	2026-05-17 21:30:40
168	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:31:56	2026-05-17 21:31:56
169	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:31:59	2026-05-17 21:31:59
170	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:34:22	2026-05-17 21:34:22
171	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:34:23	2026-05-17 21:34:23
172	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:34:24	2026-05-17 21:34:24
173	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:34:25	2026-05-17 21:34:25
174	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:34:26	2026-05-17 21:34:26
175	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:34:59	2026-05-17 21:34:59
176	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:35:00	2026-05-17 21:35:00
177	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:35:01	2026-05-17 21:35:01
178	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:35:01	2026-05-17 21:35:01
179	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:35:02	2026-05-17 21:35:02
180	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:37:55	2026-05-17 21:37:55
181	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:37:56	2026-05-17 21:37:56
182	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:37:56	2026-05-17 21:37:56
183	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:37:57	2026-05-17 21:37:57
184	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:37:58	2026-05-17 21:37:58
185	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:38:06	2026-05-17 21:38:06
186	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-17 21:38:09	2026-05-17 21:38:09
187	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:38:10	2026-05-17 21:38:10
188	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-17 21:38:11	2026-05-17 21:38:11
189	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-17 21:38:11	2026-05-17 21:38:11
190	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/audit-logs","route":"admin.audit-logs"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/audit-logs	success	2026-05-17 21:38:45	2026-05-17 21:38:45
191	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-17 21:38:47	2026-05-17 21:38:47
192	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:01:55	2026-05-18 01:01:55
193	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/analytics","route":"faculty.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/analytics	success	2026-05-18 01:01:58	2026-05-18 01:01:58
194	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:02:35	2026-05-18 01:02:35
195	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/trash","route":"admin.trash"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/trash	success	2026-05-18 01:02:39	2026-05-18 01:02:39
196	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/reports","route":"admin.reports"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/reports	success	2026-05-18 01:02:40	2026-05-18 01:02:40
197	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/audit-logs","route":"admin.audit-logs"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/audit-logs	success	2026-05-18 01:02:42	2026-05-18 01:02:42
198	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-18 01:02:44	2026-05-18 01:02:44
199	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:02:45	2026-05-18 01:02:45
200	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:03:19	2026-05-18 01:03:19
201	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:03:33	2026-05-18 01:03:33
202	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/audit-logs","route":"admin.audit-logs"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/audit-logs	success	2026-05-18 01:04:20	2026-05-18 01:04:20
203	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:04:22	2026-05-18 01:04:22
204	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:05:51	2026-05-18 01:05:51
205	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:05:52	2026-05-18 01:05:52
206	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/users","route":"admin.users"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/users	success	2026-05-18 01:05:59	2026-05-18 01:05:59
207	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/audit-logs","route":"admin.audit-logs"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/audit-logs	success	2026-05-18 01:06:03	2026-05-18 01:06:03
208	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/reports","route":"admin.reports"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/reports	success	2026-05-18 01:06:07	2026-05-18 01:06:07
209	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/trash","route":"admin.trash"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/trash	success	2026-05-18 01:06:08	2026-05-18 01:06:08
210	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:06:10	2026-05-18 01:06:10
211	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:06:20	2026-05-18 01:06:20
212	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:06:22	2026-05-18 01:06:22
213	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:06:24	2026-05-18 01:06:24
214	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:07:02	2026-05-18 01:07:02
215	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/analytics","route":"faculty.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/analytics	success	2026-05-18 01:07:04	2026-05-18 01:07:04
216	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/excuses","route":"faculty.excuses"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/excuses	success	2026-05-18 01:07:06	2026-05-18 01:07:06
217	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-18 01:07:08	2026-05-18 01:07:08
218	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-18 01:07:13	2026-05-18 01:07:13
219	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:07:14	2026-05-18 01:07:14
220	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:17:35	2026-05-18 01:17:35
221	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:17:36	2026-05-18 01:17:36
222	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:17:37	2026-05-18 01:17:37
223	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:18:07	2026-05-18 01:18:07
224	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:18:08	2026-05-18 01:18:08
225	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:18:08	2026-05-18 01:18:08
226	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:18:09	2026-05-18 01:18:09
227	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:18:10	2026-05-18 01:18:10
228	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:18:12	2026-05-18 01:18:12
229	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:18:20	2026-05-18 01:18:20
230	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:18:21	2026-05-18 01:18:21
231	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:18:22	2026-05-18 01:18:22
232	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:19:19	2026-05-18 01:19:19
233	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:19:20	2026-05-18 01:19:20
234	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:19:21	2026-05-18 01:19:21
235	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:20:42	2026-05-18 01:20:42
236	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:20:44	2026-05-18 01:20:44
237	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:20:44	2026-05-18 01:20:44
238	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:21:07	2026-05-18 01:21:07
239	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:21:13	2026-05-18 01:21:13
240	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:21:18	2026-05-18 01:21:18
241	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:21:22	2026-05-18 01:21:22
242	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:21:26	2026-05-18 01:21:26
243	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:21:30	2026-05-18 01:21:30
244	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:22:51	2026-05-18 01:22:51
245	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:22:56	2026-05-18 01:22:56
246	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:23:00	2026-05-18 01:23:00
247	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:23:03	2026-05-18 01:23:03
248	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:23:07	2026-05-18 01:23:07
249	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:23:11	2026-05-18 01:23:11
250	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:23:15	2026-05-18 01:23:15
251	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:23:18	2026-05-18 01:23:18
252	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:23:22	2026-05-18 01:23:22
253	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:23:26	2026-05-18 01:23:26
254	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:23:29	2026-05-18 01:23:29
255	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:23:33	2026-05-18 01:23:33
256	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:23:36	2026-05-18 01:23:36
257	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:23:40	2026-05-18 01:23:40
258	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:23:44	2026-05-18 01:23:44
259	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:24:01	2026-05-18 01:24:01
260	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:05	2026-05-18 01:24:05
261	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:09	2026-05-18 01:24:09
262	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:17	2026-05-18 01:24:17
263	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:24:22	2026-05-18 01:24:22
264	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:25	2026-05-18 01:24:25
265	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:29	2026-05-18 01:24:29
266	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:24:32	2026-05-18 01:24:32
267	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:36	2026-05-18 01:24:36
268	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:24:40	2026-05-18 01:24:40
269	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:44	2026-05-18 01:24:44
270	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:47	2026-05-18 01:24:47
271	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:24:51	2026-05-18 01:24:51
272	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:55	2026-05-18 01:24:55
273	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:24:58	2026-05-18 01:24:58
274	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:26:07	2026-05-18 01:26:07
275	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"student\\/analytics","route":"student.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /student/analytics	success	2026-05-18 01:26:08	2026-05-18 01:26:08
276	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:26:09	2026-05-18 01:26:09
277	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:26:24	2026-05-18 01:26:24
278	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:26:50	2026-05-18 01:26:50
279	5	marked_present_via_code	App\\Models\\AttendanceSession	1	{"student_id":5}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	student student marked present via manual code	success	2026-05-18 01:27:14	2026-05-18 01:27:14
280	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:27:25	2026-05-18 01:27:25
281	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-18 01:27:30	2026-05-18 01:27:30
282	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-18 01:27:33	2026-05-18 01:27:33
283	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/excuses","route":"faculty.excuses"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/excuses	success	2026-05-18 01:27:40	2026-05-18 01:27:40
284	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-18 01:27:42	2026-05-18 01:27:42
285	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-18 01:28:22	2026-05-18 01:28:22
286	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:28:27	2026-05-18 01:28:27
287	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:31:25	2026-05-18 01:31:25
288	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:33:13	2026-05-18 01:33:13
289	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:33:19	2026-05-18 01:33:19
290	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:33:48	2026-05-18 01:33:48
291	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:34:15	2026-05-18 01:34:15
292	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:36:17	2026-05-18 01:36:17
293	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:36:19	2026-05-18 01:36:19
294	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:36:20	2026-05-18 01:36:20
295	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:39:21	2026-05-18 01:39:21
296	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:39:22	2026-05-18 01:39:22
297	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:39:23	2026-05-18 01:39:23
298	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:39:35	2026-05-18 01:39:35
299	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:39:36	2026-05-18 01:39:36
300	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:39:37	2026-05-18 01:39:37
301	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:39:55	2026-05-18 01:39:55
302	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:39:56	2026-05-18 01:39:56
303	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:39:57	2026-05-18 01:39:57
304	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:41:32	2026-05-18 01:41:32
305	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:41:33	2026-05-18 01:41:33
306	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:41:34	2026-05-18 01:41:34
307	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:41:42	2026-05-18 01:41:42
308	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:41:43	2026-05-18 01:41:43
309	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:41:44	2026-05-18 01:41:44
310	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:44:32	2026-05-18 01:44:32
311	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:51:01	2026-05-18 01:51:01
312	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:51:05	2026-05-18 01:51:05
313	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:51:07	2026-05-18 01:51:07
314	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:54:25	2026-05-18 01:54:25
315	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-18 01:54:30	2026-05-18 01:54:30
316	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-18 01:54:32	2026-05-18 01:54:32
317	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/excuses","route":"faculty.excuses"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/excuses	success	2026-05-18 01:54:35	2026-05-18 01:54:35
318	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/analytics","route":"faculty.analytics"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/analytics	success	2026-05-18 01:54:37	2026-05-18 01:54:37
319	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/excuses","route":"faculty.excuses"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/excuses	success	2026-05-18 01:54:41	2026-05-18 01:54:41
320	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-18 01:54:43	2026-05-18 01:54:43
321	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-18 01:55:46	2026-05-18 01:55:46
322	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 01:55:48	2026-05-18 01:55:48
323	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:01:48	2026-05-18 02:01:48
324	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:01:50	2026-05-18 02:01:50
325	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:01:50	2026-05-18 02:01:50
326	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:03:07	2026-05-18 02:03:07
327	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:03:08	2026-05-18 02:03:08
328	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:03:09	2026-05-18 02:03:09
329	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:03:10	2026-05-18 02:03:10
330	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:03:11	2026-05-18 02:03:11
331	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:04:39	2026-05-18 02:04:39
332	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:04:40	2026-05-18 02:04:40
333	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:04:41	2026-05-18 02:04:41
334	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:05:11	2026-05-18 02:05:11
335	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:05:12	2026-05-18 02:05:12
336	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:05:13	2026-05-18 02:05:13
337	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:08:49	2026-05-18 02:08:49
338	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:08:50	2026-05-18 02:08:50
339	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:08:51	2026-05-18 02:08:51
340	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:08:58	2026-05-18 02:08:58
341	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:08:59	2026-05-18 02:08:59
342	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:00	2026-05-18 02:09:00
343	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:08	2026-05-18 02:09:08
344	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:09	2026-05-18 02:09:09
345	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:10	2026-05-18 02:09:10
346	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:28	2026-05-18 02:09:28
347	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:29	2026-05-18 02:09:29
348	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:30	2026-05-18 02:09:30
349	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:41	2026-05-18 02:09:41
350	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:42	2026-05-18 02:09:42
351	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:43	2026-05-18 02:09:43
352	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:51	2026-05-18 02:09:51
353	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:52	2026-05-18 02:09:52
354	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:09:53	2026-05-18 02:09:53
355	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:10:22	2026-05-18 02:10:22
356	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:10:27	2026-05-18 02:10:27
357	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:10:28	2026-05-18 02:10:28
358	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:10:36	2026-05-18 02:10:36
359	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:10:37	2026-05-18 02:10:37
360	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:10:38	2026-05-18 02:10:38
361	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/backup-settings","route":"admin.backup-settings"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/backup-settings	success	2026-05-18 02:24:31	2026-05-18 02:24:31
362	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:24:47	2026-05-18 02:24:47
363	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:25:45	2026-05-18 02:25:45
364	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:25:47	2026-05-18 02:25:47
365	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:25:47	2026-05-18 02:25:47
366	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:25:55	2026-05-18 02:25:55
367	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:25:57	2026-05-18 02:25:57
368	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:25:57	2026-05-18 02:25:57
369	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/backup-settings","route":"admin.backup-settings"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/backup-settings	success	2026-05-18 02:26:13	2026-05-18 02:26:13
370	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/backup-settings","route":"admin.backup-settings"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/backup-settings	success	2026-05-18 02:26:20	2026-05-18 02:26:20
371	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:26:21	2026-05-18 02:26:21
372	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:26:22	2026-05-18 02:26:22
373	1	manual_backup_triggered	System	\N	{"type":"files"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	\N	success	2026-05-18 02:26:33	2026-05-18 02:26:33
374	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/backup-settings","route":"admin.backup-settings"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/backup-settings	success	2026-05-18 02:26:36	2026-05-18 02:26:36
375	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:26:37	2026-05-18 02:26:37
376	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:26:38	2026-05-18 02:26:38
377	1	manual_backup_triggered	System	\N	{"type":"full"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	\N	success	2026-05-18 02:27:32	2026-05-18 02:27:32
378	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:27:49	2026-05-18 02:27:49
379	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:36:32	2026-05-18 02:36:32
380	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:36:33	2026-05-18 02:36:33
381	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:36:34	2026-05-18 02:36:34
382	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:37:01	2026-05-18 02:37:01
383	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:37:02	2026-05-18 02:37:02
384	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:37:03	2026-05-18 02:37:03
385	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:37:21	2026-05-18 02:37:21
386	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:37:22	2026-05-18 02:37:22
387	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:37:23	2026-05-18 02:37:23
388	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:38:21	2026-05-18 02:38:21
389	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:38:23	2026-05-18 02:38:23
390	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:38:23	2026-05-18 02:38:23
391	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:38:37	2026-05-18 02:38:37
392	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:38:38	2026-05-18 02:38:38
393	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:38:39	2026-05-18 02:38:39
394	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:39:10	2026-05-18 02:39:10
395	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:39:12	2026-05-18 02:39:12
396	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:39:12	2026-05-18 02:39:12
397	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:39:20	2026-05-18 02:39:20
398	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:39:21	2026-05-18 02:39:21
399	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:39:22	2026-05-18 02:39:22
400	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/backup-settings","route":"admin.backup-settings"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/backup-settings	success	2026-05-18 02:46:53	2026-05-18 02:46:53
401	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:46:57	2026-05-18 02:46:57
402	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-18 02:52:44	2026-05-18 02:52:44
403	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:53:33	2026-05-18 02:53:33
404	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:56:17	2026-05-18 02:56:17
405	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:56:19	2026-05-18 02:56:19
406	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:56:20	2026-05-18 02:56:20
407	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-18 02:58:24	2026-05-18 02:58:24
408	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-18 02:58:27	2026-05-18 02:58:27
409	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/classes","route":"faculty.classes"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/classes	success	2026-05-18 02:58:37	2026-05-18 02:58:37
410	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 02:58:40	2026-05-18 02:58:40
411	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 03:03:02	2026-05-18 03:03:02
412	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 03:03:59	2026-05-18 03:03:59
413	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 03:07:21	2026-05-18 03:07:21
414	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 03:07:22	2026-05-18 03:07:22
415	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 03:07:23	2026-05-18 03:07:23
416	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 03:07:58	2026-05-18 03:07:58
417	5	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 03:07:59	2026-05-18 03:07:59
418	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 03:08:00	2026-05-18 03:08:00
419	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"faculty\\/attendance","route":"faculty.attendance"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /faculty/attendance	success	2026-05-18 03:11:05	2026-05-18 03:11:05
420	4	viewed	Illuminate\\Routing\\Route	\N	{"path":"dashboard","route":"dashboard"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /dashboard	success	2026-05-18 03:11:13	2026-05-18 03:11:13
421	1	viewed	Illuminate\\Routing\\Route	\N	{"path":"admin\\/backup-settings","route":"admin.backup-settings"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	Accessed page: /admin/backup-settings	success	2026-05-18 03:11:44	2026-05-18 03:11:44
\.


--
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_logs (id, type, status, file_path, file_size, notes, expires_at, created_at, updated_at) FROM stdin;
1	database	failed	\N	\N	pg_dump failed with return code: 1. Output: 	2026-06-17 02:12:14	2026-05-18 02:12:14	2026-05-18 02:12:14
2	database	success	C:\\Users\\rbong\\Desktop\\school\\3rdyear\\laravel\\student-attendance-MS\\storage\\backups/db_backup_2026-05-18_022356.zip	11779	Manual backup triggered	2026-06-17 02:23:56	2026-05-18 02:23:56	2026-05-18 02:23:57
3	files	success	C:\\Users\\rbong\\Desktop\\school\\3rdyear\\laravel\\student-attendance-MS\\storage\\backups/files_backup_2026-05-18_022624.zip	101282	Manual backup triggered	2026-06-17 02:26:24	2026-05-18 02:26:24	2026-05-18 02:26:24
5	database	success	C:\\Users\\rbong\\Desktop\\school\\3rdyear\\laravel\\student-attendance-MS\\storage\\backups/db_backup_2026-05-18_022707.zip	12249	Manual backup triggered	2026-06-17 02:27:07	2026-05-18 02:27:07	2026-05-18 02:27:07
6	files	success	C:\\Users\\rbong\\Desktop\\school\\3rdyear\\laravel\\student-attendance-MS\\storage\\backups/files_backup_2026-05-18_022715.zip	101282	Manual backup triggered	2026-06-17 02:27:15	2026-05-18 02:27:15	2026-05-18 02:27:15
4	full	success	C:\\Users\\rbong\\Desktop\\school\\3rdyear\\laravel\\student-attendance-MS\\storage\\backups/full_backup_2026-05-18_022707.zip	113837	Manual full backup triggered	2026-06-17 02:27:07	2026-05-18 02:27:07	2026-05-18 02:27:24
7	database	pending	\N	\N	Manual backup triggered	2026-06-17 03:11:52	2026-05-18 03:11:52	2026-05-18 03:11:52
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache (key, value, expiration) FROM stdin;
laravel-cache-as|127.0.0.1:timer	i:1779052295;	1779052295
laravel-cache-as|127.0.0.1	i:1;	1779052295
laravel-cache-ac3478d69a3c81fa62e60f5c3696165a4e5e6ac4:timer	i:1779050915;	1779050915
laravel-cache-sys_avg_response_time	d:519;	1779160304
laravel-cache-sys_total_requests	i:640;	1779160304
laravel-cache-ac3478d69a3c81fa62e60f5c3696165a4e5e6ac4	i:1;	1779050915
laravel-cache-1b6453892473a467d07372d45eb05abc2031647a:timer	i:1779051559;	1779051559
laravel-cache-1b6453892473a467d07372d45eb05abc2031647a	i:1;	1779051559
laravel-cache-356a192b7913b04c54574d18c28d46e6395428ab:timer	i:1779051325;	1779051325
laravel-cache-356a192b7913b04c54574d18c28d46e6395428ab	i:1;	1779051325
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: class_sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_sections (id, subject_id, faculty_id, name, schedule_details, created_at, updated_at, semester_id, deleted_at, lock_version) FROM stdin;
1	1	4	Section B	MWF, 10:00 - 12:00	2026-05-17 20:45:36	2026-05-17 20:45:47	1	\N	1
2	2	4	Section A	TTH, 9:00 - 11:00	2026-05-17 20:58:45	2026-05-17 20:58:45	1	\N	0
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.enrollments (id, class_section_id, student_id, status, created_at, updated_at, deleted_at) FROM stdin;
1	2	5	active	2026-05-17 20:59:08	2026-05-17 20:59:08	\N
\.


--
-- Data for Name: excuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.excuses (id, student_id, class_section_id, date, reason, file_path, status, created_at, updated_at, attendance_session_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2026_05_14_233829_create_subjects_table	1
5	2026_05_14_233838_create_class_sections_table	1
6	2026_05_14_233844_create_enrollments_table	1
7	2026_05_14_233848_create_attendance_sessions_table	1
8	2026_05_14_233857_create_attendance_records_table	1
9	2026_05_16_000000_create_audit_logs_table	1
10	2026_05_16_133151_create_semesters_table	1
11	2026_05_16_133315_add_semester_id_to_class_sections_table	1
12	2026_05_16_134347_add_faculty_id_and_is_active_to_semesters_table	1
13	2026_05_16_141050_add_attendance_code_to_attendance_sessions_table	1
14	2026_05_16_141104_create_excuses_table	1
15	2026_05_16_add_qr_code_to_attendance_sessions	1
16	2026_05_17_062539_add_attendance_session_id_to_excuses_table	1
17	2026_05_17_084154_create_notifications_table	1
18	2026_05_17_140235_add_status_avatar_permissions_to_users_table	1
19	2026_05_17_141636_add_otp_columns_to_users_table	1
20	2026_05_17_145337_add_last_activity_to_users_table	1
21	2026_05_17_164946_create_report_configurations_table	1
22	2026_05_17_202327_add_soft_deletes_to_tables	2
23	2026_05_17_202332_add_lock_version_to_tables	2
24	2026_05_18_012000_add_notification_preferences_to_users_table	3
25	2026_05_18_020135_create_backup_logs_table	4
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, type, notifiable_type, notifiable_id, data, read_at, created_at, updated_at) FROM stdin;
1650d364-e832-4b81-9f5b-a49ef1be0151	App\\Notifications\\SessionStartedNotification	App\\Models\\User	5	{"type":"session_started","message":"A new attendance session has started for INTRO-734.","session_id":1,"class_section_id":2}	\N	2026-05-18 01:26:37	2026-05-18 01:26:37
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: report_configurations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_configurations (id, user_id, name, type, filters, is_favorite, schedule_frequency, email_to, last_run_at, next_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: semesters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.semesters (id, name, created_at, updated_at, is_active, faculty_id) FROM stdin;
1	1st Semester 2026-2027	2026-05-17 20:45:13	2026-05-17 20:45:13	t	4
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
hL0IxvvRabtdOiQw9sQfJaXg7oUVz7uDEfHdwmYX	4	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	eyJfdG9rZW4iOiJma21wQ1ZHYnB0UnhRbjFRZW93c1IwZmh6Rm0xbW8xd0V4bHBpdnByIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTI3LjAuMC4xOjgwMDBcL2Rhc2hib2FyZCIsInJvdXRlIjoiZGFzaGJvYXJkIn0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjo0LCJwYXNzd29yZF9oYXNoX3dlYiI6IjFhMWZjODI1YjM4Y2VmNmJhMWQ1MTkwN2JkYTk3YTBhNTgzNTg5NDE0YzcwYTBlOTYzMGQ3YWMyNDA5NThiMDUiLCJvdHBfdmVyaWZpZWRfNCI6dHJ1ZX0=	1779073445
Zt6On2NowF8eUc0PJcZssUdh06Pfvaxv0fVULg8w	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	eyJfdG9rZW4iOiJSejJsOUR4ZnNQYzAzbjhYdVJEOWxtMTdzY2t6OGc3TGFjY0JwNHNJIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cDpcL1wvbG9jYWxob3N0OjgwMDBcL2Rhc2hib2FyZCJ9LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvbG9jYWxob3N0OjgwMDBcL2xvZ2luIiwicm91dGUiOiJsb2dpbiJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19	1779073462
iFThH5IiUbmW5amTumWB0bDRT2eCoscWaW2DNpgt	5	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	eyJfdG9rZW4iOiJ6MVd4VlBOQnN2NElNTHk5eDRBUmxrSjBZN1ZiazZreTZRUjcwclZjIiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MDAwXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjo1LCJwYXNzd29yZF9oYXNoX3dlYiI6ImJjNzdlMTUwMzlkNzZiZTlmZWY5M2ViNmQ5NzYxNjUxYzJlZDc4OTc0YjgyN2RiYjZmYmMzMDZiZjg4MWM5YWYiLCJvdHBfdmVyaWZpZWRfNSI6dHJ1ZX0=	1779073679
m57QSIw5Ed7EbZ9QcjKpg1tMqIqt4IFevhjHJeWK	4	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	eyJfdG9rZW4iOiJSUkVDTkJPdUwxMGdTcTF5NW5GTzduNXc4YVZnZ0ZZaDdmeVBiRnZ4IiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MDAwXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjo0LCJwYXNzd29yZF9oYXNoX3dlYiI6IjFhMWZjODI1YjM4Y2VmNmJhMWQ1MTkwN2JkYTk3YTBhNTgzNTg5NDE0YzcwYTBlOTYzMGQ3YWMyNDA5NThiMDUiLCJvdHBfdmVyaWZpZWRfNCI6dHJ1ZX0=	1779073873
nmVfdBcazkRM4bnKWRwVseZXdZxmjIMUUrZPQeYq	1	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	eyJfdG9rZW4iOiJWNHhodjdFUmJLWjRwa3NrMTVPckJjSW0xc21Db2ppRnFjUWhyOWF3IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTI3LjAuMC4xOjgwMDBcL2FkbWluXC9iYWNrdXAtc2V0dGluZ3MiLCJyb3V0ZSI6ImFkbWluLmJhY2t1cC1zZXR0aW5ncyJ9LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MSwicGFzc3dvcmRfaGFzaF93ZWIiOiJlOGRhM2ZmNDBjYjA1OWU3ODUyOTM1Y2U4MDdjZDBjM2E0MGZjOGUxNjYyZDgzMDBmMTFjNjdhMzc0NzdlNzQ1Iiwib3RwX3ZlcmlmaWVkXzEiOnRydWV9	1779073904
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subjects (id, code, name, description, created_at, updated_at) FROM stdin;
1	DATAS-891	Data Structures 	\N	2026-05-17 20:45:36	2026-05-17 20:45:36
2	INTRO-734	Intro to Comp	\N	2026-05-17 20:58:45	2026-05-17 20:58:45
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, first_name, middle_name, last_name, identity_id, email, email_verified_at, password, role, device_fingerprint, remember_token, created_at, updated_at, status, avatar_path, permissions, otp_code, otp_expires_at, last_activity, deleted_at, lock_version, notification_preferences) FROM stdin;
4	faculty	Bulahao	faculty	11111	s.bongo.sethlaurence@cmu.edu.ph	2026-05-17 20:43:00	$2y$12$3LNUsxhjxW8uTTgYe5kQ1u5vjI5sCY.kJHDYKRALlRWfMfwqNEfK6	faculty	\N	\N	2026-05-17 20:42:47	2026-05-18 03:11:05	active	\N	\N	\N	\N	2026-05-18 03:11:05	\N	0	\N
1	SETH LAURENCE	BULAHAO	Bongo	2023301260	rbongo581@gmail.com	2026-05-17 20:23:58	$2y$12$5Z0UNNbdf8XtdoE8m8xmbeN2UnY9..jx.UlmSY4QMvaObTyKexlmi	admin	\N	\N	2026-05-17 20:23:40	2026-05-18 03:11:44	active	\N	\N	\N	\N	2026-05-18 03:11:44	\N	0	\N
2	Isabella	Lee	Thomas	2023200423	isabella.thomas1@gmail.com	\N	$2y$12$.u5psIQRRnnGlcqr6I8Sg.hOd1/URzM55CxTsVbM6O/Hw7Y3r9UQW	admin	\N	\N	2026-05-17 20:34:56	2026-05-17 20:34:56	active	\N	\N	\N	\N	\N	\N	0	\N
3	Daniel	Paul	Anderson	2023889513	daniel.anderson6@gmail.com	\N	$2y$12$1cLzEGRn3qC8K.3cpxXyHemg8pLLUBHZXt5O9x5xLoV8r.gVGpV4m	admin	\N	\N	2026-05-17 20:34:57	2026-05-17 20:34:57	active	\N	\N	\N	\N	\N	\N	0	\N
9	sdad	asd	asdsa	66666	asdsa@gmail.com	\N	$2y$12$d1.I5zRXJjupOB1sBDv4w.O5rWZrJLq3KxygoGzId2W2ZcfW0jHn6	student	\N	\N	2026-05-17 21:13:40	2026-05-17 21:13:40	active	\N	\N	\N	\N	\N	\N	0	\N
5	student	\N	student	22222	sethfirstgithubbongo@gmail.com	2026-05-17 20:47:35	$2y$12$6aoDmz3aW47/.o.GqLncDOXfqGm2ZIVyCrmNGQnX/HmKO68DWus7C	student	ac2477ed-d5da-4d7b-a193-195cd97f768e	\N	2026-05-17 20:47:25	2026-05-18 03:07:22	active	\N	\N	\N	\N	2026-05-18 03:07:22	\N	0	\N
\.


--
-- Name: attendance_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendance_records_id_seq', 1, true);


--
-- Name: attendance_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendance_sessions_id_seq', 3, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 421, true);


--
-- Name: backup_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_logs_id_seq', 7, true);


--
-- Name: class_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.class_sections_id_seq', 2, true);


--
-- Name: enrollments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.enrollments_id_seq', 1, true);


--
-- Name: excuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.excuses_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 25, true);


--
-- Name: report_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_configurations_id_seq', 1, false);


--
-- Name: semesters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.semesters_id_seq', 1, true);


--
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subjects_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 9, true);


--
-- Name: attendance_records attendance_records_attendance_session_id_student_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_attendance_session_id_student_id_unique UNIQUE (attendance_session_id, student_id);


--
-- Name: attendance_records attendance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_pkey PRIMARY KEY (id);


--
-- Name: attendance_sessions attendance_sessions_attendance_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_sessions
    ADD CONSTRAINT attendance_sessions_attendance_code_unique UNIQUE (attendance_code);


--
-- Name: attendance_sessions attendance_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_sessions
    ADD CONSTRAINT attendance_sessions_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: class_sections class_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_sections
    ADD CONSTRAINT class_sections_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_class_section_id_student_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_class_section_id_student_id_unique UNIQUE (class_section_id, student_id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: excuses excuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.excuses
    ADD CONSTRAINT excuses_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: report_configurations report_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_configurations
    ADD CONSTRAINT report_configurations_pkey PRIMARY KEY (id);


--
-- Name: semesters semesters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.semesters
    ADD CONSTRAINT semesters_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_code_unique UNIQUE (code);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_identity_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_identity_id_unique UNIQUE (identity_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_action_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_action_index ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_created_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_created_at_index ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_model_type_index ON public.audit_logs USING btree (model_type);


--
-- Name: audit_logs_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_user_id_index ON public.audit_logs USING btree (user_id);


--
-- Name: cache_expiration_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cache_expiration_index ON public.cache USING btree (expiration);


--
-- Name: cache_locks_expiration_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cache_locks_expiration_index ON public.cache_locks USING btree (expiration);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: notifications_notifiable_type_notifiable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_notifiable_type_notifiable_id_index ON public.notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: attendance_records attendance_records_attendance_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_attendance_session_id_foreign FOREIGN KEY (attendance_session_id) REFERENCES public.attendance_sessions(id) ON DELETE CASCADE;


--
-- Name: attendance_records attendance_records_student_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_student_id_foreign FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attendance_sessions attendance_sessions_class_section_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_sessions
    ADD CONSTRAINT attendance_sessions_class_section_id_foreign FOREIGN KEY (class_section_id) REFERENCES public.class_sections(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: class_sections class_sections_faculty_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_sections
    ADD CONSTRAINT class_sections_faculty_id_foreign FOREIGN KEY (faculty_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: class_sections class_sections_semester_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_sections
    ADD CONSTRAINT class_sections_semester_id_foreign FOREIGN KEY (semester_id) REFERENCES public.semesters(id) ON DELETE SET NULL;


--
-- Name: class_sections class_sections_subject_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_sections
    ADD CONSTRAINT class_sections_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: enrollments enrollments_class_section_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_class_section_id_foreign FOREIGN KEY (class_section_id) REFERENCES public.class_sections(id) ON DELETE CASCADE;


--
-- Name: enrollments enrollments_student_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_student_id_foreign FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: excuses excuses_attendance_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.excuses
    ADD CONSTRAINT excuses_attendance_session_id_foreign FOREIGN KEY (attendance_session_id) REFERENCES public.attendance_sessions(id) ON DELETE CASCADE;


--
-- Name: excuses excuses_class_section_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.excuses
    ADD CONSTRAINT excuses_class_section_id_foreign FOREIGN KEY (class_section_id) REFERENCES public.class_sections(id) ON DELETE CASCADE;


--
-- Name: excuses excuses_student_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.excuses
    ADD CONSTRAINT excuses_student_id_foreign FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: report_configurations report_configurations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_configurations
    ADD CONSTRAINT report_configurations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: semesters semesters_faculty_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.semesters
    ADD CONSTRAINT semesters_faculty_id_foreign FOREIGN KEY (faculty_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

